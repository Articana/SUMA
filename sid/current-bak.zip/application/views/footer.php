<div style="height:64px;">&nbsp;</div>
	<footer class="footer">
		<p class="text-right" style="padding-right:16px"><small>Sistema de Información Docente - SID beta 2017 | SID 1.0.0 2021.</small>
		<br><small>Elaborado por: <a href="" data-toggle="modal" data-target="#info" >contacto</a></small>
		</p>
	</footer>

	<div class="modal fade" id="info">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Datos Personales</h4>
      </div>

      <div class="modal-body">
      	<div class="form-group">
      	<div class="input-group">
      <h3>TSU. Daniela Flores Hernandez</h3>
      <p><strong>Correo Electrónico:</strong> <a class="text-info" href="mailto:hfloresdaniela@gmail.com">&nbsp;hfloresdaniela@gmail.com</a>
      <br>
      <strong>Teléfono:</strong> (044) 492-145-70-30
      </p>
      
      <br>

      <h3>TSU. Martha Elena Ledezma Cruz</h3>
      <p><strong>Correo Electrónico:</strong>
      <br>
      <strong>Teléfono:</strong>(044) 
      </p>
      
      <br>

      <h3>TSU. Ana Cecilia Romo Flores</h3>
        <p><strong>Correo Electrónico:</strong>
      <br>
      <strong>Teléfono:</strong> (044) 492-121-49-88
      </p>
      
      <br>
       
       
		</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success " data-dismiss="modal">Aceptar</button>
       
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</body>
</html>
