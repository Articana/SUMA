<div class="container">
<div class="panel panel-default">
<div class="panel-heading">
</div>

<div class="panel-body">
<h3>Listado</h3><br><br>

  <div  style="text-align:right">
<a class="btn btn-xs btn-primary" href="cac/vccarga"> + Crear</a>
</div>
<div class="table-responsive">
	<table class="table table-striped">
		<thead>
			<tr>
				<th><small>Nombre completo</small></th>
				<th><small>Carrera</small></th>
				<th><small>Nivel Habilitacion</small></th>
				<th><small>Acciones</small></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><small>422</small></td>
				<td><small>Braulio Eleazar Miranda Gutiérrez</small></td>
				<td><small>Profesor de Asignatura</small></td>
				<td>
					<small><a class="btn btn-xs btn-danger" href="" title="Eliminar"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Eliminar</a></small>
					<small><a class="btn btn-xs btn-success" href="" title="Modificar"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Editar</a></small>
				</td>
				
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="5"></td>
			</tr>
		</tfoot>
	</table>
</div>
</div>
</div>
