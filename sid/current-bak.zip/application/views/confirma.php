<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
        <title>Sistema de Información Docente | Registro Docente</title>
        <script>
                alert('Registro completo!');
                window.location.href = "<?php echo base_url(); ?>";
        </script>
</head>
<body>

<div style="padding:24px;">&nbsp;</div> 
<div class="container">
<div class="panel panel-default">
<div class="panel-heading" id="panel_principal">
</div>
<div class="panel-body">
<h3>Registro de Docente Realizado!</h3>
<div class="col-md-4">
</div>
</div>
</div>
</div>

        <div style="height:64px;">&nbsp;</div>
        <footer class="footer">
                <p class="text-right"><small>Sistema de Información Docente - SID beta 2017 | SID 1.0.0 2021.</small></p>
        </footer>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</body>
</html>




